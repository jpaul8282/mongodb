package api

// +k8s:deepcopy-gen=package
