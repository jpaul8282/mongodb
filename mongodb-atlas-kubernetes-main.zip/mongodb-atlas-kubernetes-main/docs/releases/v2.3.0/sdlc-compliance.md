SSDLC Compliance Report: Atlas Kubernetes Operator Manager v2.3.0
=================================================================

- Release Creators: igor.karpukhin@mongodb.com
- Created On:       2024-06-07

Overview:

- **Product and Release Name**

    - Atlas Kubernetes Operator v2.3.0, 2024-06-07.
    - Release Type: Minor

- **Process Document**
  - http://go/how-we-develop-software-doc

- **Tool used to track third party vulnerabilities**
  - Silk

- **Dependency Information**
  - See SBOMS Lite manifests (CycloneDX in JSON format) for [Intel](./linux_amd64.sbom.json) or [ARM](./linux_arm64.sbom.json)

- **Static Analysis Report**
  - No SAST findings. Our CI system blocks merges on any SAST findings.
  - No vulnerabilities were ignored for this release.

- **Release Signature Report**
  - Image signatures enforced by CI pipeline.
  - See [Signature verification instructions here](../../dev/signed-images.md)
  - Self-verification shortcut:
    ```shell
    make verify IMG=mongodb/mongodb-atlas-kubernetes-operator:2.3.0 SIGNATURE_REPO=mongodb/signatures
    ```

- **Security Testing Report**
  - Available as needed from Cloud Security.

- **Security Assessment Report**
  - Available as needed from Cloud Security.

Assumptions and attestations:

- Internal processes are used to ensure CVEs are identified and mitigated within SLAs.

- All Operator images are signed by MongoDB, with signatures stored at `docker.io/mongodb/signatures`.
